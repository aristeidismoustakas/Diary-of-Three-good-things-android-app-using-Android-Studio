package com.example.aristeidismoustakas.three_reasons_to_smile;

import android.provider.BaseColumns;

/**
 * Created by Αριστείδης on 24/4/2016.
 */
public class MemoContract {

    public MemoContract() {}

    public static abstract class MemoEntry implements BaseColumns {
        public static final String TABLE_DATES = "DATES";
        public static final String TABLE_NOTES = "NOTES";
        public static final String DATE = "DATE";
        public static final String NOTE = "NOTE";
        public static final String RANK = "RANK";
        public static final String DATE_ID = "DATE_ID";

    }

    private static final String TEXT_TYPE = " TEXT";
    private static final String INT_TYPE = " INTEGER";
    private static final String COMMA_SEP = ",";


    public static final String SQL_CREATE_DATES = //this table contains records of dates(in string type)
            "CREATE TABLE " + MemoEntry.TABLE_DATES + " (" +
                    MemoEntry._ID + " INTEGER PRIMARY KEY," +
                    MemoEntry.DATE + TEXT_TYPE + " )";


    public static final String SQL_CREATE_NOTES = // this table contains the notes of the dates and a foreign key of the corresponding date entry in the TABLE_DATES.
            "CREATE TABLE " + MemoEntry.TABLE_NOTES + " (" +
                    MemoEntry._ID + " INTEGER PRIMARY KEY," +
                    MemoEntry.NOTE + TEXT_TYPE + COMMA_SEP+
                    MemoEntry.RANK + INT_TYPE + COMMA_SEP+
                    MemoEntry.DATE_ID + INT_TYPE +" )"        ;



    public static final String SQL_DELETE_DATES =
            "DROP TABLE IF EXISTS " + MemoEntry.TABLE_DATES;

    public static final String SQL_DELETE_NOTES =
            "DROP TABLE IF EXISTS " + MemoEntry.TABLE_NOTES;





}
