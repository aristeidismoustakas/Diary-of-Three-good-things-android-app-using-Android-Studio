package com.example.aristeidismoustakas.three_reasons_to_smile;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import  com.example.aristeidismoustakas.three_reasons_to_smile.MemoContract.*;

import java.text.DateFormat;
import java.util.Arrays;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private SimpleCursorAdapter adapter;
    MemoDBHelper dbHelper;
    SQLiteDatabase db;
    String[] projection;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         listView=(ListView) findViewById(R.id.listView);
        dbHelper=new MemoDBHelper(this);
        db=dbHelper.getReadableDatabase();
        loadFromDB();

    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                loadFromDB();
/*               Cursor cursor = db.query(
                        MemoEntry.TABLE_DATES,  // The table to query
                        projection,                               // The columns to return
                        null,                                // The columns for the WHERE clause
                        null,                            // The values for the WHERE clause
                        null,                                     // don't group the rows
                        null,                                     // don't filter by row groups
                        null                                        // The sort order
                );
                adapter.changeCursor(cursor);*/
            }
        }
    }


    public void add(View view) {
        Intent intent = new Intent(this, Add_edit.class);
        intent.putExtra("isAdd",true);
        startActivityForResult(intent, 1);
    }


    public void loadFromDB(){
        projection = new String[]{
                MemoEntry._ID,
                MemoEntry.DATE
        };

        String sortOrder = MemoEntry.DATE + " DESC";
        final Cursor cursor = db.query(MemoEntry.TABLE_DATES,projection,null,null,null,null,sortOrder);
        String[] fromColumns=new String[]{MemoEntry.DATE};
        int[] toViews=new int[]{R.id.item};
        adapter=new SimpleCursorAdapter(this,R.layout.item_view,cursor,fromColumns,toViews,0);
        adapter.setViewBinder(new SimpleCursorAdapter.ViewBinder(){
        @Override
            public boolean setViewValue(View v, Cursor c,int column)
                {
                    if (column==1)
                    {
                        TextView tv=(TextView) v;
                        String date=cursor.getString(cursor.getColumnIndex(MemoEntry.DATE));
                        int[] formatedDate= formatDate(date);
                        DateFormat f=DateFormat.getDateInstance();
                        String d=f.format( new Date(formatedDate[0]-1900,formatedDate[1]-1,formatedDate[2]) );
                        tv.setText(d);
                        return true;
                    }
                    return false;
                }
        });
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent=new Intent(MainActivity.this,Add_edit.class);
                Log.v("MainActivity","id is  "+ id );
                intent.putExtra("id",id);
                intent.putExtra("isAdd",false);
                startActivityForResult(intent,1);
            }
        });

    }


    public static int[] formatDate(String date) // return an array of int which has in pos 0 the year in pos 1 the month and in pos 2 the day.
    {
        String[] tokens=date.split("/");
        int[] ret=new int[3];
        ret [0]=Integer.parseInt(tokens[0]);
        ret [1]=Integer.parseInt(tokens[1]);
        ret [2]=Integer.parseInt(tokens[2]);
        return ret;

    }

}


