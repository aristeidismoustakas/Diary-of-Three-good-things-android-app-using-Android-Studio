package com.example.aristeidismoustakas.three_reasons_to_smile;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.DatePicker;
import java.util.Calendar;
import java.util.Date;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.support.v4.app.DialogFragment;
import android.app.AlertDialog;
import android.content.DialogInterface;

import java.text.DateFormat;

import com.example.aristeidismoustakas.three_reasons_to_smile.MemoContract.*;

public class Add_edit extends AppCompatActivity {
    static final String STATE= "state";
    static final String IS_ADD= "isAdd";
    private MemoDBHelper dbHelper;
    private long id;
    private boolean isAdd;
    private static String state="";
    static EditText dateView;
    private EditText firstSmile;
    private EditText secondSmile;
    private EditText thirdSmile;
    private Button save_edit_button;
    private Button delete_button;
    static String fullDate="";
    static String title;
    static String lastDate="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);
        Intent intent = getIntent();
        dateView=(EditText) findViewById(R.id.dateView);
        firstSmile = (EditText) findViewById(R.id.firstSmile);
        secondSmile = (EditText) findViewById(R.id.secondSmile);
        thirdSmile = (EditText) findViewById(R.id.thirdSmile);
        save_edit_button = (Button) findViewById(R.id.save_edit);
        delete_button = (Button) findViewById(R.id.delete);
        isAdd = intent.getBooleanExtra("isAdd", false);
        id = (long) intent.getLongExtra("id", 0);
        if (isAdd) {
            addMode();
        }
        else
        {
           previewMode(true);
        }

        dateView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker(v);
            }
        });

    }


    public void showDatePicker(View v) {
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.show(getSupportFragmentManager(), "datePicker");
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        // Save the app state
        savedInstanceState.putString(STATE, state);
        savedInstanceState.putBoolean(IS_ADD, isAdd);
        super.onSaveInstanceState(savedInstanceState);
    }


    public static class DatePickerFragment extends DialogFragment implements
            DatePickerDialog.OnDateSetListener {

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            int year=0;
            int month=0;
            int day=0;
            if(state=="add"){
            final Calendar c = Calendar.getInstance();
                year = c.get(Calendar.YEAR);
                month = c.get(Calendar.MONTH);
                day = c.get(Calendar.DAY_OF_MONTH);}
            else {
                int[] aaDate=formatDate(fullDate);
                year = aaDate[0];
                month = aaDate[1]-1;
                day = aaDate[2];

            }

            return new DatePickerDialog(getActivity(), this, year, month, day);
        }

        public void onDateSet(DatePicker view, int year, int month, int day) {
            if(day<10 && (month+1)<10)
                fullDate =   year+ "/0"+ (month+1) + "/0" +day   ;
            else if(day<10)
                fullDate =   year+ "/"+ (month+1) + "/0" +day   ;
            else if ((month+1)<10)
                fullDate =   year+ "/0"+ (month+1) + "/" +day   ;
            else
                fullDate =   year+ "/"+ (month+1) + "/" +day   ;
            DateFormat f=DateFormat.getDateInstance();
            title=f.format( new Date(year-1900,month,day) );
            dateView.setText(title);
        }
    }


    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        state= savedInstanceState.getString(STATE);
        isAdd=savedInstanceState.getBoolean(IS_ADD);
        if (isAdd) {
            addMode();
        }
        else if(state.equals("edit")){
            editMode();
        }
        else
        {
            previewMode(false);
        }

    }

    public void previewMode(boolean needLoad)
    {
        state="preview";
        if(needLoad)
        {
            loadFromDB();
        }
        dateView.setEnabled(false);
        firstSmile.setEnabled(false);
        secondSmile.setEnabled(false);
        thirdSmile.setEnabled(false);
        delete_button.setVisibility(Button.VISIBLE);
        save_edit_button.setText(R.string.edit);



    }

    public void editMode()
    {
        state="edit";
        firstSmile.setEnabled(true);
        secondSmile.setEnabled(true);
        thirdSmile.setEnabled(true);
        dateView.setEnabled(true);
        delete_button.setVisibility(Button.INVISIBLE);
        save_edit_button.setText(R.string.save);
    }

    public void addMode()
    {
        state="add";
        getSupportActionBar().setTitle(R.string.new_entry);
        delete_button.setVisibility(Button.INVISIBLE);
        save_edit_button.setText(R.string.save);
    }


    public void save_edit(View v) {
        dbHelper = new MemoDBHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        ContentValues firstNoteValues = new ContentValues();
        ContentValues secondNoteValues = new ContentValues();
        ContentValues thirdNoteValues = new ContentValues();
        if (state.equals("add")) {
            boolean isDateOk=checkDate(fullDate);
            if ( isDateOk && dateView.getText().toString().length()>0 &&(firstSmile.getText().toString().trim().length()>0 || secondSmile.getText().toString().trim().length()>0 ||thirdSmile.getText().toString().trim().length()>0)) {
                values.put(MemoEntry.DATE, fullDate);
                long newRowId = db.insert(MemoEntry.TABLE_DATES, null, values);
                String firstThing = firstSmile.getText().toString().trim();
                String secondThing = secondSmile.getText().toString().trim();
                String thirdThing = thirdSmile.getText().toString().trim();
                firstNoteValues.put(MemoEntry.RANK, 1 + "");
                firstNoteValues.put(MemoEntry.DATE_ID, newRowId + "");
                firstNoteValues.put(MemoEntry.NOTE, firstThing);
                secondNoteValues.put(MemoEntry.RANK, 2 + "");
                secondNoteValues.put(MemoEntry.DATE_ID, newRowId + "");
                secondNoteValues.put(MemoEntry.NOTE, secondThing);
                thirdNoteValues.put(MemoEntry.RANK, 3 + "");
                thirdNoteValues.put(MemoEntry.DATE_ID, newRowId + "");
                thirdNoteValues.put(MemoEntry.NOTE, thirdThing);
                db.insert(MemoEntry.TABLE_NOTES, null, firstNoteValues);
                db.insert(MemoEntry.TABLE_NOTES, null, secondNoteValues);
                db.insert(MemoEntry.TABLE_NOTES, null, thirdNoteValues);
                Toast.makeText(this, R.string.save_is_ok, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent();
                setResult(RESULT_OK, intent);
                finish();
            } else if(dateView.getText().toString().length()==0){
                Toast.makeText(this, R.string.valid_date, Toast.LENGTH_SHORT).show();

            }else if(!isDateOk)
            {
                Toast.makeText(this, R.string.isAlrUsed, Toast.LENGTH_SHORT).show();
            }else
            {
                Toast.makeText(this, R.string.atLeastOne, Toast.LENGTH_SHORT).show();
            }

        } else if (state.equals("preview")) {
            editMode();
            Toast.makeText(this, R.string.touch_to_edit, Toast.LENGTH_SHORT).show();

        } else {
            boolean isDateOk=checkDate(fullDate);
            if (isDateOk && dateView.getText().toString().length()>0 &&(firstSmile.getText().toString().trim().length()>0 || secondSmile.getText().toString().trim().length()>0 ||thirdSmile.getText().toString().trim().length()>0)) {
                values.put(MemoEntry.DATE, fullDate);
                db.update(MemoEntry.TABLE_DATES, values, "_ID = ?", new String[]{"" + id});
                String firstThing = firstSmile.getText().toString().trim();
                String secondThing = secondSmile.getText().toString().trim();
                String thirdThing = thirdSmile.getText().toString().trim();
                firstNoteValues.put(MemoEntry.NOTE, firstThing);
                secondNoteValues.put(MemoEntry.NOTE, secondThing);
                thirdNoteValues.put(MemoEntry.NOTE, thirdThing);
                db.update(MemoEntry.TABLE_NOTES, firstNoteValues, "DATE_ID = ? and RANK = ? ", new String[]{"" + id, "" + 1});
                db.update(MemoEntry.TABLE_NOTES, secondNoteValues, "DATE_ID = ? and RANK = ? ", new String[]{"" + id, "" + 2});
                db.update(MemoEntry.TABLE_NOTES, thirdNoteValues, "DATE_ID = ? and RANK = ? ", new String[]{"" + id, "" + 3});
                Toast.makeText(this, R.string.changes_save, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent();
                setResult(RESULT_OK, intent);
                finish();
                 }else if(dateView.getText().toString().length()==0){
                Toast.makeText(this, R.string.valid_date, Toast.LENGTH_SHORT).show();

                }else if(!isDateOk)
                    {
                        Toast.makeText(this, R.string.isAlrUsed, Toast.LENGTH_SHORT).show();
                    }else
                    {
                        Toast.makeText(this, R.string.atLeastOne, Toast.LENGTH_SHORT).show();
                    }

                }
    }



    public void loadFromDB() //Load the informations of an entry from the database.
    {
        String[] projectionDate = new String[]{
                MemoEntry._ID,
                MemoEntry.DATE
        };


        String[] projectionNotes = new String[]{
                MemoEntry._ID,
                MemoEntry.NOTE,
                MemoEntry.RANK,
                MemoEntry.DATE_ID
        };
        dbHelper = new MemoDBHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Log.v("Add_edit","id is  "+ id );
        Cursor cursorDate = db.query(MemoEntry.TABLE_DATES, projectionDate, "_ID = ?", new String[]{"" + id}, null, null, null);
        cursorDate.moveToFirst();
        fullDate = cursorDate.getString(cursorDate.getColumnIndex(MemoEntry.DATE));
        int[] formatedDate= formatDate(fullDate);
        DateFormat f=DateFormat.getDateInstance();
        String d=f.format( new Date(formatedDate[0]-1900,formatedDate[1]-1,formatedDate[2]) );
        title = d;
        lastDate = fullDate;
        dateView.setText(title);
        updateBar(title);
        String sortOrder = MemoEntry.RANK + " ASC";
        Cursor cursorNote = db.query(MemoEntry.TABLE_NOTES, projectionNotes, "DATE_ID = ?", new String[]{"" + id}, null, null,sortOrder);
        cursorNote.moveToFirst();
        String aa=cursorNote.getString(cursorNote.getColumnIndex(MemoEntry.NOTE));
        if(aa.length()!=0)
            firstSmile.setText(aa);
        cursorNote.moveToNext();
        String bb=cursorNote.getString(cursorNote.getColumnIndex(MemoEntry.NOTE));
        if(bb.length()!=0)
            secondSmile.setText(bb);
        cursorNote.moveToNext();
        String cc=cursorNote.getString(cursorNote.getColumnIndex(MemoEntry.NOTE));
        if(cc.length()!=0)
            thirdSmile.setText(cc);
    }



    public void deleteDay(View v ) // Delete an entry from databases.
    {
        dbHelper = new MemoDBHelper(this);

        new AlertDialog.Builder(this)
                .setTitle(R.string.alert_title)
                .setMessage(R.string.alert_message)
                .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        SQLiteDatabase db = dbHelper.getReadableDatabase();
                        db.delete(MemoEntry.TABLE_NOTES, MemoEntry.DATE_ID+ "=" + id , null);
                        db.delete(MemoEntry.TABLE_DATES, MemoEntry._ID + "=" + id , null);
                        Intent intent = new Intent();
                        setResult(RESULT_OK, intent);
                        finish();
                    }
                })
                .setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                    }
                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }


    public void updateBar(String theDate) // update the bar of the app.
    {getSupportActionBar().setTitle(theDate);}


 public static int[] formatDate(String date) // return an array of int which has in pos 0 the year in pos 1 the month and in pos 2 the day.
    {
        String[] tokens=date.split("/");
        int[] ret=new int[3];
        ret [0]=Integer.parseInt(tokens[0]);
        ret [1]=Integer.parseInt(tokens[1]);
        ret [2]=Integer.parseInt(tokens[2]);
        return ret;

    }




    public boolean checkDate(String aDate) //Return false if date is already used in another entry.
    {
        if(state.equals("edit")&& lastDate.equals(aDate))
             return true;
        String[] projectionDate = new String[]{
                MemoEntry._ID,
                MemoEntry.DATE,
        };
        dbHelper = new MemoDBHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.query(MemoEntry.TABLE_DATES, projectionDate, "DATE = ?", new String[]{"" + aDate}, null, null, null);
        if(c.moveToFirst()) {
            do {
                return false;
            } while (c.moveToNext());
        }
            return true;
    }
}



/*
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent();
                setResult(RESULT_OK, intent);
                finish();
                return (true);
        }
        return(super.onOptionsItemSelected(item));
    }


    @Override
    public void onBackPressed() {
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        super.onBackPressed();
    }*/